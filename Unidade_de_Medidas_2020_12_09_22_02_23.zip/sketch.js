var   tela = 1;
var largura = 220;
var altura = 45;
var xMenu = 50;
var yMenu1 = 200;
var yMenu2 = 270;
var yMenu3 = 340;
var x = 10;
var acertou = false;
var errou = false;
var errou1 = false;
var errou2 = false;
var vetorxr = [0];
var velocidade = 3;
var m 
var cont3 = 0;


let img;
let img1;
let img2;
let imag3;
let img4;
let img5;
let img6;
let img7;
let img8;
let img9;

function preload() {
  img = loadImage('girafa.png');
  img1 = loadImage('maca.png');
  img2 = loadImage('suco.png')
  img3 = loadImage('fundo.png');
  img4 = loadImage('Eu.jpg')
  img5 = loadImage('fit.png')
  img6 = loadImage('kik.png')
  img7 = loadImage('pipoca.png')
  img8 = loadImage('leite.png')
  img9 = loadImage('regua.png')
  m = createAudio('tetris.mp3')
}


function setup() {
  createCanvas(800, 500)
  m.loop();
}

function draw() {
  background(img);
  textStyle(NORMAL);

  //Tela de Menu
  if (tela == 1) {
    //Iniciar o Jogo
    textAlign(CENTER);
    textSize(26);

    if (mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu1 && mouseY < yMenu1 + altura) {
      stroke(200);
      fill(256);
      rect(xMenu, yMenu1, largura, altura, 15);
      if (mouseIsPressed) {
        tela = tela + 1;
      }
    }

    fill(0);
    noStroke();
    text("Jogar", 160, 230);
    noFill();
    stroke(255);
    rect(xMenu, yMenu1, largura, altura, 15);

    if (mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu2 && mouseY < yMenu2 + altura) {
      stroke(200);
      fill(256);
      rect(xMenu, yMenu2, largura, altura, 15);
      if (mouseIsPressed) {
        tela = tela + 2;
      }
    }

    fill(0);
    noStroke();
    text("Instruções", 165, 300);
    noFill();
    stroke(255);
    rect(xMenu, yMenu2, largura, altura, 15);

    //creditos
    if (mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu3 && mouseY < yMenu3 + altura) {
      stroke(200);
      fill(256);
      rect(xMenu, yMenu3, largura, altura, 15);
      if (mouseIsPressed) {
        tela = tela + 3;
      }
    }

    fill(0);
    noStroke();
    text("Créditos", 160, 365);
    noFill();
    stroke(255);
    rect(xMenu, yMenu3, largura, altura, 15);
    
    image(img9, vetorxr,450)

    for(i=0; i<1; i++){
      vetorxr[i] = vetorxr[i] + velocidade;
       if (vetorxr[i]>300){
      velocidade = -3;   
      }
      if(vetorxr[i]<0){
      velocidade = 3;
      }
    }
  }
 
  //tela 2
  if (tela == 2) {

    background(20);
    stroke(255);
    fill(20);
    image(img3, 0, 0, 800, 500);
    image(img1, 130, 230, 160, 160);
    image(img2, 320, 220, 180, 180);
    textSize(25);
    fill(0);
    text('Qual dos alimentos compramos a litros?', 320, 60)
    if (mouseX > 320 && mouseX < 320 + 180 && mouseY > 220 && mouseY < 220 + 180) {
      if (mouseIsPressed) {
        acertou = true;
        errou = false;
      }
    }
    if (acertou == true) {
      tela=5
    }
 if (mouseX > 130 && mouseX < 130 + 160 && mouseY > 230 && mouseY < 230 + 160) {
      if (mouseIsPressed) {
        errou = true;
      }
    }
    if (errou == true) { 
      text("A maçã faz parte da unidade de medidas em quilograma.", 340, 95)
      textSize(25)
      text("Você errou, tente novamente!", 360, 150) 
    }
  }
 
  if (tela==5){
    acertou = false;
    errou = false;
    background(img3);
    stroke(255);
    fill(20);
    image(img3, 0, 0, 800, 500);
    image(img5, 130, 230, 160, 160);
    image(img6, 320, 220, 180, 180);
    textSize(25);
    fill(0);
    text('Qual dos elementos usamos para medir comprimento?', 320, 120)
 if (mouseX > 130 && mouseX < 130 + 160 && mouseY > 230 && mouseY < 230 + 160) {
      if (mouseIsPressed) {
        acertou = true;
        errou = false;
      }
    }
    if (acertou == true) {
        tela=6
      }
    if (mouseX > 320 && mouseX < 320 + 180 && mouseY > 220 && mouseY < 220 + 180) {
    
      if (mouseIsPressed) {
        errou = true;
      }
    }
    if (errou == true) {
      fill(20)
      text("Você errou, tente novamente!", 350, 210)
      textSize(25)
      fill(20)
      text("A balança é usada para pesar.", 350, 160)
    }
  }
  
  if (tela==6){
    cont3++;
    acertou = false;
    errou = false
    background(img3);
    stroke(255);
    fill(20);
    image(img3, 0, 0, 800, 500);
    image(img7, 130, 230, 160, 160);
    image(img8, 320, 220, 180, 180);
    textSize(25);
    fill(0);
    text('Qual dos alimentos compramos por gramas?', 320, 120)
    if (mouseX > 130 && mouseX < 130 + 160 && mouseY > 230 && mouseY < 230 + 160) {
      if (mouseIsPressed) {
        acertou = true;
        errou = false;
      }
    }
    if(cont3 > 20)
    if (acertou == true) {
      tela = 7;
      }
  
    if (mouseX > 320 && mouseX < 320 + 180 && mouseY > 220 && mouseY < 220 + 180) {
   if (mouseIsPressed) {
        errou = true;
      }
    }
    if (errou == true) {
      fill(20)
      text("Você errou, tente novamente!", 350, 210)
      textSize(25)
      fill(20)
      text("A unidade de medida do leite é litros.", 350, 160)
    }
  }
   if (tela==7){
    acertou = false;
    errou = false
    background(img3);
    fill(20)
    textSize(25)
    text("Parabéns, hoje você aprendeu um pouco sobre unidade de medidas...", 400, 300)
     image(img9, vetorxr,100)

    for(i=0; i<1; i++){
      vetorxr[i] = vetorxr[i] + velocidade;
       if (vetorxr[i]>490){
      velocidade = -3;   
      }
      if(vetorxr[i]<0){
      velocidade = 3;
      }
    }
   }
 
     //Informações do jogo
  if (tela == 3) {
    background(img3);
    fill(240);

    textSize(18);
    noStroke();
    textAlign(CENTER);
    text("O que são unidade de medidas? As unidades de medidas são formas de quantificar diferentes grandezas físicas. Por exemplo: litro (l), mililitro (ml), quilograma(kg), grama(g), entre outros. O objetivo do jogo é que o jogador identifique as unidades de medidas de acordo com os elementos.A cada acerto o jogador pulará de fase", 80, 90, 500, 200);
    textSize(18)
    text('Publico alvo: 3° ano do ensino fundamental.', 290, 250)
    textSize(18)
    text('Disciplina: Matemática.', 60, 20, 265)
    textSize(18)
    text('Habilidade:(EF03MA20) Estimar e medir capacidade e massa, utilizando unidades de medida não padronizadas e padronizadas mais usadas (litro, mililitro, quilograma, grama e miligrama) reconhecendo-as em leitura de rótulos e embalagens, entre outros. ', 95, 305, 460, 410)
    
image(img9, vetorxr,450)

    for(i=0; i<1; i++){
      vetorxr[i] = vetorxr[i] + velocidade;
       if (vetorxr[i]>600){
      velocidade = -3;   
      }
      if(vetorxr[i]<0){
      velocidade = 3;
      }
    }
  }

  //créditos
  if (tela == 4) {
    background(img3);
    fill(240);
    textSize(20);
    noStroke();
    textAlign(LEFT);
    text("Programadora: Hiliane Vitória Trajano da Silva", 255, 300, 260, 180);
    textSize(20)
    text("UFRN - Projeto educativo - Lógica de programação", 255, 360, 260,190);
    image(img4, 270, 100, 180, 180)

    image(img9, vetorxr,220)

    for(i=0; i<1; i++){
      vetorxr[i] = vetorxr[i] + velocidade;
       if (vetorxr[i]>180){
      velocidade = -2;   
      }
      if(vetorxr[i]<0){
      velocidade = 2;
      }
    }
  }

  //voltar para a tela de inicio;
  if (tela == 2 || tela == 3 || tela == 4 || tela == 5 || tela == 6 || tela == 7 ) {
    if (mouseX > 365 && mouseX < 365 + 420 && mouseY > 420 && mouseY < 420 + 420) {
      stroke(200);
      fill(20);
      rect(365, 420, 100, 50, 15);
      if (mouseIsPressed) {
        tela = 1;
      }
      cont3 = 0;
    }

    fill(240);
    noStroke();
    textSize(20);
    noStroke();
    textAlign(CENTER);
    text("Menu", 287, 440, 260, 290);
  }
}


// Link do video: https://youtu.be/s1GEhZGVdwk